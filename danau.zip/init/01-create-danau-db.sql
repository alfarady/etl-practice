CREATE DATABASE IF NOT EXISTS `danau`;
GRANT ALL ON `danau`.* TO 'gudang'@'%';