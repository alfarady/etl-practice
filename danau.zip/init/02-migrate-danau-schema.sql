USE danau

CREATE TABLE users (
    UserID INT PRIMARY KEY AUTO_INCREMENT,
    Code VARCHAR(10),
    Name VARCHAR(100),
    Email VARCHAR(100),
    PhoneNumber VARCHAR(15),
    Role VARCHAR(50),
    DepartmentID INT
);

CREATE TABLE departments (
    DepartmentID INT PRIMARY KEY AUTO_INCREMENT,
    DepartmentName VARCHAR(100)
);

CREATE TABLE rooms (
    RoomID INT PRIMARY KEY AUTO_INCREMENT,
    Code VARCHAR(10),
    Floor INT,
    Capacity INT
);

CREATE TABLE documents (
    DocumentID INT PRIMARY KEY AUTO_INCREMENT,
    RoomID INT,
    RequesterID INT,
    SKPBApproverID INT,
    SarprasApproverID INT,
    TendikID INT,
    EventID INT,
    ApprovalStatus VARCHAR(20),
    ReferenceNumber VARCHAR(100),
    Name VARCHAR(100),
    Type VARCHAR(100),
    UsageStartTime DATETIME,
    UsageEndTime DATETIME,
    CreatedDate DATETIME,
    SKPBApprovedDate DATETIME,
    SKPBRejectedDate DATETIME,
    SarprasApprovedDate DATETIME,
    SarprasRejectedDate DATETIME
);
