USE gudang

-- Table for Dim_Approver
CREATE TABLE Dim_Approver (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    Code INT,
    Name VARCHAR(255),
    Type VARCHAR(255),
    Email VARCHAR(255),
    PhoneNumber VARCHAR(20)
);

-- Table for Dim_Room
CREATE TABLE Dim_Room (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    Code VARCHAR(50),
    Floor INT,
    Capacity INT
);

-- Table for Dim_Document
CREATE TABLE Dim_Document (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    ReferenceNumber VARCHAR(100),
    Name VARCHAR(255),
    UsageStartTime DATETIME,
    UsageEndTime DATETIME,
    CreatedDate DATETIME,
    SKPBApprovedDate DATETIME,
    SKPBRejectedDate DATETIME,
    SarprasApprovedDate DATETIME,
    SarprasRejectedDate DATETIME
);

-- Table for Dim_Requester
CREATE TABLE Dim_Requester (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    Code VARCHAR(50),
    Name VARCHAR(255),
    Email VARCHAR(255),
    UnitDepartement VARCHAR(255),
    PhoneNumber VARCHAR(20)
);

-- Table for Dim_Tendik
CREATE TABLE Dim_Tendik (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    Code VARCHAR(50),
    Name VARCHAR(255)
);

-- Table for DateTime (Date dimension table)
CREATE TABLE DateTime (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    Day VARCHAR(255),
    Month VARCHAR(255),
    Year INT,
    UsageStartTime DATETIME,
    UsageEndTime DATETIME,
    FilledFormDate DATETIME,
    DocumentCreatedDate DATETIME,
    DocumentSKPBApprovedDate DATETIME,
    DocumentSKPBRejectedDate DATETIME,
    DocumentSarprasApprovedDate DATETIME,
    DocumentSarprasRejectedDate DATETIME
);

-- Table for Fact_RoomBorrowingFaculty
CREATE TABLE Fact_RoomBorrowingFaculty (
    FormID INT PRIMARY KEY AUTO_INCREMENT,
    RoomID INT,
    DocumentID INT,
    SKPBApproverID INT,
    SarprasApproverID INT,
    TendikID INT,
    RequesterID INT,
    DateTimeID INT,
    EventName VARCHAR(255),
    EventType VARCHAR(255),
    ApprovalStatus VARCHAR(255),
    UsageStartTime DATETIME,
    UsageEndTime DATETIME
);
