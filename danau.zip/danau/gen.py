import pandas as pd
import random
from datetime import datetime, timedelta

# Function to create user data
def generate_users(num_users):
    users = []
    roles = ['Requester', 'SKPBApprover', 'SarprasApprover', 'Tendik']
    for i in range(1, num_users + 1):
        code = f"USER{i:03d}"
        name = f"User {i}"
        email = f"user{i}@example.com"
        phone = f"08{random.randint(100000000, 999999999)}"
        role = random.choice(roles)
        department_id = random.randint(1, 5)
        users.append([i, code, name, email, phone, role, department_id])
    return users

# Function to create departments
def generate_departments():
    return [
        [1, "Administration"],
        [2, "Facilities"],
        [3, "IT"],
        [4, "Finance"],
        [5, "HR"]
    ]

# Function to create rooms
def generate_rooms(num_rooms):
    rooms = []
    for i in range(1, num_rooms + 1):
        code = f"Room{i:03d}"
        floor = random.randint(1, 5)
        capacity = random.randint(10, 50)
        rooms.append([i, code, floor, capacity])
    return rooms

# Function to create events
def generate_events(num_events):
    events = []
    for i in range(1, num_events + 1):
        name = f"Event {i}"
        event_type = random.choice(["Pelatihan", "Kegiatan", "Lain-Lain"])
        events.append(event_type)
    return events

# Function to create reference number
def generate_reference_number(doc_id):
    month = random.randint(1, 12)
    year = datetime.now().year
    return f"{doc_id}/BEM/FTEIC/{month:02d}/{year}"

# Function to create event name
def generate_event_name():
    event_type = random.choice(["Pelatihan", "Kegiatan", "Lomba"])
    penyelenggara = random.choice(["BEM FTEIC", "BEM FSAD", "Jurusan Sistem Informasi", "BEM FTE", "BEM FTI"])
    return f"{event_type} oleh {penyelenggara}"

# Function to generate usage times
def generate_usage_times():
    start_time = datetime(random.randint(2023, 2024), random.randint(1, 12), random.randint(1, 28), random.randint(8, 18), random.randint(0, 59))
    end_time = start_time + timedelta(hours=random.randint(1, 6))  # Duration between 1-6 hours
    return start_time, end_time

# Function to generate created date
def generate_created_date(usage_start_time):
    return usage_start_time - timedelta(days=random.randint(30, 90))

# Function to generate approval dates
def generate_approval_dates(created_date):
    approval_decision = random.choice(["approved", "rejected"])
    if approval_decision == "approved":
        skpb_approved = created_date + timedelta(days=random.randint(1, 10))
        sarpras_approved = skpb_approved + timedelta(days=random.randint(1, 3))  # Sarpras always after SKPB
        return skpb_approved, None, sarpras_approved, None
    else:
        skpb_rejected = created_date + timedelta(days=random.randint(1, 10))
        sarpras_rejected = skpb_rejected + timedelta(days=random.randint(1, 3))  # Sarpras always after SKPB
        return None, skpb_rejected, None, sarpras_rejected

# Generate dummy data for Users
users = generate_users(10)
df_users = pd.DataFrame(users, columns=["UserID", "Code", "Name", "Email", "PhoneNumber", "Role", "DepartmentID"])

# Generate dummy data for Departments
departments = generate_departments()
df_departments = pd.DataFrame(departments, columns=["DepartmentID", "DepartmentName"])

# Generate dummy data for Rooms
rooms = generate_rooms(10)
df_rooms = pd.DataFrame(rooms, columns=["RoomID", "Code", "Floor", "Capacity"])

# Generate dummy data for Events
events = generate_events(5)

# Generate data for Documents
data = []
for i in range(1, 51):
    document_id = i
    reference_number = generate_reference_number(i)
    name = generate_event_name()
    usage_start_time, usage_end_time = generate_usage_times()
    created_date = generate_created_date(usage_start_time)
    skpb_approved_date, skpb_rejected_date, sarpras_approved_date, sarpras_rejected_date = generate_approval_dates(created_date)
    
    room_id = random.randint(1, 10)
    requester_id = random.randint(1, 10)
    skpb_approver_id = random.randint(1, 10)
    sarpras_approver_id = random.randint(1, 10)
    tendik_id = random.randint(1, 10)
    event_type = events[random.randint(0, 4)]
    approval_status = "Approved" if skpb_approved_date else "Rejected"
    
    data.append([
        document_id,
        room_id,
        requester_id,
        skpb_approver_id,
        sarpras_approver_id,
        tendik_id,
        event_type,
        approval_status,
        reference_number,
        name,
        usage_start_time,
        usage_end_time,
        created_date, 
        skpb_approved_date, 
        skpb_rejected_date, 
        sarpras_approved_date, 
        sarpras_rejected_date
    ])

# Create DataFrame for Documents
df_document = pd.DataFrame(data, columns=[
    "DocumentID", "RoomID", "RequesterID", "SKPBApproverID", "SarprasApproverID", 
    "TendikID", "EventType", "ApprovalStatus", "ReferenceNumber", "Name", 
    "UsageStartTime", "UsageEndTime", "CreatedDate", "SKPBApprovedDate", 
    "SKPBRejectedDate", "SarprasApprovedDate", "SarprasRejectedDate"
])

# Export all tables to CSV
df_users.to_csv('Users.csv', index=False)
df_departments.to_csv('Departments.csv', index=False)
df_rooms.to_csv('Rooms.csv', index=False)
df_document.to_csv('Documents.csv', index=False)

# Display the first few rows of each table for verification
(df_users.head(), df_departments.head(), df_rooms.head(), df_document.head())
